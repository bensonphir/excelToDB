CREATE TABLE `laru` (
  
  `EmployeeNumber` varchar(50) NOT NULL,
  `Surname` varchar(100) DEFAULT NULL,
  `FirstName` varchar(100) DEFAULT NULL,
  `SecondName` varchar(100) DEFAULT NULL,
  `ID_Number` varchar(100) DEFAULT NULL,
  `Period` varchar(100) DEFAULT NULL,
  `Occupation` varchar(100) DEFAULT NULL,
  `Job_Drade` varchar(100) DEFAULT NULL,
  `UNZALARU_Medical` varchar(100) DEFAULT NULL,
  `UNZALARU_Medical_Excess` varchar(100) DEFAULT NULL,
  `UNZALARU_Medical_Joining` varchar(100) DEFAULT NULL,
  `UNZALARU_Medical_Card_Fee` varchar(100) DEFAULT NULL,
  `UNZALARU_membership` varchar(100) DEFAULT NULL,
  `UNZALARU_Business_Venture` varchar(100) DEFAULT NULL,
  `UNZALARU_MLIFE_Funeral_Sc` varchar(100) DEFAULT NULL,
  
  
  
  PRIMARY KEY (`EmployeeNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;