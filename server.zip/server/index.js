const express = require("express")
const app = express()
const bodyParser = require("body-parser")
const fileupload = require("express-fileupload");
const cors = require("cors")
const mysql = require("mysql");
const bodyparser = require('body-parser')


app.use(express.static('./public'))
app.use(bodyparser.json())
app.use(
  bodyparser.urlencoded({
    extended: true,
  }),
)

const db = mysql.createPool({
  connectionLimit : 100,
    host:"localhost",
    user:"root",
    password:"",
    database: "test",
    dialect: "mysql",
    pool: {
        max: 5,
        min: 0,
        acquire: 30000,
        idle: 10000
      }
})


















app.use(cors());

app.use(fileupload());
app.use(express.static("files"));
app.use(bodyParser.json());
app.use(express.json());

app.use(bodyParser.urlencoded({extended:true}))

app.post('api/post',(req,res)=>{
  const { EmployeeNumber,ID_Number,FirstName, SecondName,Job_Drade}= req.body;
  const qu='INSERT INTO laru ( EmployeeNumber,ID_Number,FirstName, SecondName,Job_Drade) VALUES (?,?,?,?,?)'
db.query(qu,[ EmployeeNumber,ID_Number,FirstName, SecondName,Job_Drade],(error,input)=>{
  if (error){console.log("error")}
  else{res.send(input)}
})

})


app.get("/api/view/:EmployeeNumber",(req,res)=>{
  const {EmployeeNumber}=req.params;
  const ql= "SELECT * FROM laru WHERE EmployeeNumber=?"
  db.query(ql,EmployeeNumber,(q,out)=>{
    res.send(out)
  })



})


app.get("api/all",(req,res)=>{
  
  const ql= "SELECT * FROM laru"
  db.query(ql,(q,out)=>{
    res.send(out)
  })



})

app.get('/api/total',(req,res)=>{
  
    const s= 'SELECT SUM(UNZALARU_membership) AS total FROM laru WHERE UNZALARU_Medical <=900 ;';
    db.query(s,(error,member)=>{
        res.send(member)
        

        
    })
    
})

app.get('/api/totalm',(req,res)=>{
  
  const s= 'SELECT SUM(UNZALARU_Medical) AS total FROM laru WHERE UNZALARU_Medical=300;';
  
  db.query(s,(error,med)=>{
      res.send(med)
      console.log("error",error)

      
  })
  
})

app.get('/api/MissMembership',(req,res)=>{
  
    const s= 'SELECT EmployeeNumber,ID_Number,FirstName, SecondName,Job_Drade FROM laru WHERE UNZALARU_membership=0';
    db.query(s,(error,mem)=>{
        res.send(mem)
        console.log("error",error)

        
    })
    
})

app.get('/api/join',(req,res)=>{
  
  const s= 'SELECT EmployeeNumber,ID_Number,FirstName,Job_Drade,Surname FROM laru WHERE UNZALARU_Medical_Joining=300';
  db.query(s,(error,me)=>{
      res.send(me)
      console.log("error",error)

      
  })
  
})
app.get('/api/view/:EmployeeNumber',(req,res)=>{
  const {EmployeeNumber}= req.params;
  
  const v= 'SELECT * FROM laru WHERE EmployeeNumber=?';
  db.query(v,EmployeeNumber,(error,view)=>{
    if (error){console.log ("failde")}
    else {console.log(view)}
      res.send(view)
      console.log(view)
      
      
      

      
  })
  
})



app.get('/api/medical_missing',(req,res)=>{
    const select= 'SELECT EmployeeNumber,ID_Number,FirstName, SecondName,Job_Drade, Surname FROM laru WHERE UNZALARU_Medical=0  ';
    db.query(select,(error,medm)=>{
        res.send(medm)
        
  
        
    })
    
  })

  app.get('/api/members',(req,res)=>{
    const sel= 'SELECT EmployeeNumber,Surname,FirstName,ID_Number FROM laru WHERE  UNZALARU_membership<2000';
    db.query(sel,(error,tit)=>{
        res.send(tit)
       
  
        
    })
    
  })
  app.get('/add',(req,res)=>{
    const name= "INSERT INTO Medicals (EmployeeNumber,Surname,FirstName,ID_Number) VALUES(?,?,?,?)"
    db.query(name,(err,suname)=>{
      res.send(suname);
      console.log("nipano tuli")
      if(err){
        res.send(suname)
      }
    })
    
  })


  app.get('/api/Med',(req,res)=>{
    const select= 'SELECT * FROM Medicals;';
    db.query(select,(error,medd)=>{
        res.send(medd)
       
  
        
    })
    
  })

  
app.listen(4000,()=>{
    console.log("app working");
})