const express =require('express');
const app =express();
var multer  = require('multer');
var upload = multer({ dest: 'upload/'});
var fs = require('fs');

/** Permissible loading a single file, 
    the value of the attribute "name" in the form of "recfile". **/
    app.get("/api/view/:EmployeeNumber",(req,res)=>{
        const {EmployeeNumber}=req.params;
        const ql= "SELECT * FROM laru WHERE EmployeeNumber=?"
        db.query(ql,EmployeeNumber,(q,out)=>{
          res.send(out)
          console.log(out)
        })
      
      
      
      })
      app.get("/api/view",(req,res)=>{
        console.log("yes")
        })
      
      
      
    

app.listen(5050,(err,res)=>{
    if (err){console.log("yakanga ttt")}
    console.log("yakanga")
})